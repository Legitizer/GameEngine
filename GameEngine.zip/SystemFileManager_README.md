# SystemFileManager
A C++ library to manage system files
