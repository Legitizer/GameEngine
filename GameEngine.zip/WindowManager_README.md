# WindowManager
This is a C++ library that uses GLFW to manage windows.